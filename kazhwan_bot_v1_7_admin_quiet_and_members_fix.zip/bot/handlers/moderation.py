import json
import logging
from datetime import datetime, time, timedelta, timezone

from telegram import ChatPermissions, Update
from telegram.constants import ChatMemberStatus
from telegram.ext import ChatMemberHandler, CommandHandler, ContextTypes, MessageHandler, filters

from bot.handlers.admin import is_admin

logger = logging.getLogger(__name__)

IRAN_TZ = timezone(timedelta(hours=3, minutes=30), name="Iran")
def _parse_hhmm(value: str) -> time:
    hour, minute = (int(x) for x in value.split(":", 1))
    return time(hour, minute)


def _is_quiet_at(now: time, start: time, end: time) -> bool:
    # Supports both overnight windows (23:00 -> 11:00) and same-day windows.
    if start == end:
        return False
    if start < end:
        return start <= now < end
    return now >= start or now < end



def _open_permissions() -> ChatPermissions:
    """Known-good daytime permissions for normal members.

    We explicitly enable every message/media permission instead of restoring a
    possibly stale snapshot. This prevents the group from remaining locked if a
    previous Railway restart happened while the chat was already restricted.
    """
    return ChatPermissions(
        can_send_messages=True,
        can_send_audios=True,
        can_send_documents=True,
        can_send_photos=True,
        can_send_videos=True,
        can_send_video_notes=True,
        can_send_voice_notes=True,
        can_send_polls=True,
        can_send_other_messages=True,
        can_add_web_page_previews=True,
        can_change_info=False,
        can_invite_users=True,
        can_pin_messages=False,
        can_manage_topics=False,
    )

def _locked_permissions() -> ChatPermissions:
    return ChatPermissions(
        can_send_messages=False,
        can_send_audios=False,
        can_send_documents=False,
        can_send_photos=False,
        can_send_videos=False,
        can_send_video_notes=False,
        can_send_voice_notes=False,
        can_send_polls=False,
        can_send_other_messages=False,
        can_add_web_page_previews=False,
        can_change_info=False,
        can_invite_users=False,
        can_pin_messages=False,
        can_manage_topics=False,
    )


async def lock_group(context: ContextTypes.DEFAULT_TYPE) -> None:
    settings = context.application.bot_data["settings"]
    db = context.application.bot_data["db"]
    chat_id = settings.group_chat_id
    if not chat_id:
        return

    try:
        saved = await db.get_saved_group_permissions(chat_id)
        if saved is None:
            chat = await context.bot.get_chat(chat_id)
            permissions = chat.permissions or ChatPermissions(can_send_messages=True)
            await db.save_group_permissions(chat_id, json.dumps(permissions.to_dict()))

        await context.bot.set_chat_permissions(
            chat_id=chat_id,
            permissions=_locked_permissions(),
            use_independent_chat_permissions=True,
        )
        logger.info("Quiet hours enabled for group %s", chat_id)
    except Exception:
        logger.exception("Failed to enable quiet hours")


async def unlock_group(context: ContextTypes.DEFAULT_TYPE) -> None:
    settings = context.application.bot_data["settings"]
    db = context.application.bot_data["db"]
    chat_id = settings.group_chat_id
    if not chat_id:
        return

    try:
        await context.bot.set_chat_permissions(
            chat_id=chat_id,
            permissions=_open_permissions(),
            use_independent_chat_permissions=True,
        )
        await db.clear_group_permissions(chat_id)
        logger.info("Quiet hours disabled for group %s", chat_id)
    except Exception:
        logger.exception("Failed to disable quiet hours")


async def enforce_quiet_hours(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Self-heal the schedule if Railway restarts or a daily job is missed."""
    settings = context.application.bot_data["settings"]
    if not settings.group_chat_id:
        return
    db = context.application.bot_data["db"]
    quiet = await db.get_quiet_settings(settings.group_chat_id)
    if not quiet["enabled"]:
        if await db.get_saved_group_permissions(settings.group_chat_id):
            await unlock_group(context)
        return
    now = datetime.now(IRAN_TZ).time().replace(tzinfo=None)
    should_lock = _is_quiet_at(now, _parse_hhmm(quiet["start"]), _parse_hhmm(quiet["end"]))
    if should_lock:
        if not await db.get_saved_group_permissions(settings.group_chat_id):
            await lock_group(context)
    elif await db.get_saved_group_permissions(settings.group_chat_id):
        await unlock_group(context)


async def quiet_on_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.effective_user or not is_admin(update.effective_user.id, context):
        return
    await lock_group(context)
    await update.effective_message.reply_text("🔒 حالت سکوت گروه فعال شد.")


async def quiet_off_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.effective_user or not is_admin(update.effective_user.id, context):
        return
    await unlock_group(context)
    await update.effective_message.reply_text("🔓 محدودیت ارسال پیام گروه برداشته شد.")


async def initialize_quiet_hours(application) -> None:
    """Use DB-backed quiet hours; watchdog applies changes without a redeploy."""
    settings = application.bot_data["settings"]
    if not settings.group_chat_id:
        logger.warning("Quiet hours not scheduled because GROUP_CHAT_ID is empty")
        return
    if application.job_queue is None:
        raise RuntimeError("JobQueue is unavailable. Install python-telegram-bot with the job-queue extra.")

    application.job_queue.run_repeating(
        enforce_quiet_hours, interval=60, first=5, name="kazhwan_quiet_watchdog"
    )

    class StartupContext:
        def __init__(self, app):
            self.application = app
            self.bot = app.bot
    await enforce_quiet_hours(StartupContext(application))


async def track_group_activity(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    settings = context.application.bot_data["settings"]
    if not update.effective_chat or update.effective_chat.id != settings.group_chat_id:
        return
    if not update.effective_user or update.effective_user.is_bot:
        return

    db = context.application.bot_data["db"]
    await db.touch_member_activity(
        telegram_id=update.effective_user.id,
        username=update.effective_user.username,
        display_name=update.effective_user.full_name,
    )


async def welcome_new_member(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    change = update.chat_member
    if change is None:
        return

    settings = context.application.bot_data["settings"]
    if change.chat.id != settings.group_chat_id:
        return

    old_status = change.old_chat_member.status
    new_status = change.new_chat_member.status
    member = change.new_chat_member.user

    was_member = old_status in {
        ChatMemberStatus.MEMBER,
        ChatMemberStatus.ADMINISTRATOR,
        ChatMemberStatus.OWNER,
    }
    is_member = new_status in {
        ChatMemberStatus.MEMBER,
        ChatMemberStatus.ADMINISTRATOR,
        ChatMemberStatus.OWNER,
    }

    if not was_member and is_member and not member.is_bot:
        db = context.application.bot_data["db"]
        await db.touch_member_activity(
            telegram_id=member.id,
            username=member.username,
            display_name=member.full_name,
        )
        # A member may enter via invite/manual approval instead of the onboarding Join Request.
        # If a KZH profile already exists, synchronize BTC membership here too.
        if await db.get_user(member.id):
            await db.mark_existing_group_member(member.id)
        await context.bot.send_message(
            chat_id=change.chat.id,
            text=f"🌿 {member.full_name} عزیز، به گروه خوش اومدی.",
        )


def moderation_handlers():
    return [
        CommandHandler("quieton", quiet_on_command),
        CommandHandler("quietoff", quiet_off_command),
        ChatMemberHandler(welcome_new_member, ChatMemberHandler.CHAT_MEMBER),
        MessageHandler(filters.ChatType.GROUPS, track_group_activity),
    ]
