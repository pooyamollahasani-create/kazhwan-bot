from datetime import datetime, timedelta, timezone
import re
from sqlalchemy import BigInteger, Boolean, DateTime, Integer, String, Text, func, inspect, or_, select
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

REFERRAL_REWARD_POINTS = 5
TRIP_POINTS = {
    "domestic_day": 5,
    "domestic_multi": 15,
    "international": 100,
}


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    telegram_username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    full_name: Mapped[str] = mapped_column(String(160))
    phone: Mapped[str] = mapped_column(String(32))
    city: Mapped[str] = mapped_column(String(100))
    discovery_source: Mapped[str] = mapped_column(String(100))
    rules_accepted: Mapped[bool] = mapped_column(Boolean, default=False)
    channel_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    member_code: Mapped[str | None] = mapped_column(String(20), unique=True, nullable=True)
    referral_code: Mapped[str | None] = mapped_column(String(24), unique=True, nullable=True)
    referred_by_telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True, index=True)
    referral_count: Mapped[int] = mapped_column(Integer, default=0)
    referral_rewarded: Mapped[bool] = mapped_column(Boolean, default=False)
    group_approved: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(30), default="active")
    points: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    last_activity_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )


class BtcMembership(Base):
    __tablename__ = "btc_memberships"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    btc_code: Mapped[str | None] = mapped_column(String(20), unique=True, nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(20), default="active", index=True)
    rules_accepted: Mapped[bool] = mapped_column(Boolean, default=False)
    joined_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )



class Activity(Base):
    __tablename__ = "activities"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, index=True)
    activity_type: Mapped[str] = mapped_column(String(60))
    title: Mapped[str] = mapped_column(String(200))
    details: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )


class PendingJoin(Base):
    __tablename__ = "pending_joins"

    telegram_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    group_chat_id: Mapped[int] = mapped_column(BigInteger)
    user_chat_id: Mapped[int] = mapped_column(BigInteger)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )


class MemberActivity(Base):
    __tablename__ = "member_activity"

    telegram_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    telegram_username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    display_name: Mapped[str] = mapped_column(String(160))
    first_seen_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    last_activity_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), index=True
    )


class GroupModerationState(Base):
    __tablename__ = "group_moderation_state"

    group_chat_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    saved_permissions_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    quiet_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    quiet_start: Mapped[str] = mapped_column(String(5), default="23:00")
    quiet_end: Mapped[str] = mapped_column(String(5), default="11:00")


class Trip(Base):
    __tablename__ = "trips"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    trip_code: Mapped[str | None] = mapped_column(String(24), unique=True, nullable=True, index=True)
    telegram_chat_id: Mapped[int | None] = mapped_column(BigInteger, unique=True, index=True, nullable=True)
    title: Mapped[str] = mapped_column(String(200))
    trip_type: Mapped[str] = mapped_column(String(24), default="domestic_multi", index=True)
    points_value: Mapped[int] = mapped_column(Integer, default=15)
    start_date_text: Mapped[str] = mapped_column(String(80))
    end_date_text: Mapped[str] = mapped_column(String(80))
    status: Mapped[str] = mapped_column(String(20), default="open", index=True)
    archived: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    archived_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    archived_chat_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    pre_archive_status: Mapped[str | None] = mapped_column(String(20), nullable=True)
    merged_into_trip_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    created_by_telegram_id: Mapped[int] = mapped_column(BigInteger)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )


class TripParticipant(Base):
    __tablename__ = "trip_participants"

    trip_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, primary_key=True, index=True)
    status: Mapped[str] = mapped_column(String(20), default="declared", index=True)
    declared_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    points_awarded: Mapped[bool] = mapped_column(Boolean, default=False)
    awarded_points: Mapped[int] = mapped_column(Integer, default=0)


def _normalize_name(value: str) -> str:
    value = (value or "").strip().replace("ي", "ی").replace("ك", "ک")
    value = re.sub(r"\s+", " ", value)
    return value.casefold()


def _normalize_phone(value: str | None) -> str | None:
    if not value:
        return None
    digits = "".join(ch for ch in value if ch.isdigit())
    if digits.startswith("98") and len(digits) >= 12:
        digits = "0" + digits[2:]
    if len(digits) == 10 and digits.startswith("9"):
        digits = "0" + digits
    return digits or None


class GuestTraveler(Base):
    __tablename__ = "guest_travelers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    full_name: Mapped[str] = mapped_column(String(160), index=True)
    normalized_name: Mapped[str] = mapped_column(String(180), index=True)
    phone: Mapped[str | None] = mapped_column(String(32), nullable=True)
    normalized_phone: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)
    linked_telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True, index=True)
    created_by_telegram_id: Mapped[int] = mapped_column(BigInteger)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    linked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class GuestTripParticipant(Base):
    __tablename__ = "guest_trip_participants"

    trip_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    guest_id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    status: Mapped[str] = mapped_column(String(20), default="declared", index=True)
    pending_points: Mapped[int] = mapped_column(Integer, default=0)
    declared_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )


class Database:
    def __init__(self, url: str):
        self.engine = create_async_engine(url, future=True)
        self.sessions = async_sessionmaker(self.engine, expire_on_commit=False)

    async def init(self) -> None:
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
            await conn.run_sync(self._migrate_users_table)
            await conn.run_sync(self._migrate_trips_table)
            await conn.run_sync(self._migrate_group_moderation_table)

        # Backfill referral codes for users that existed before this version.
        async with self.sessions() as session:
            result = await session.execute(select(User).where(User.referral_code.is_(None)))
            users = result.scalars().all()
            for user in users:
                user.referral_code = f"KZH-R{user.id:06d}"

            # Existing successful referrals were already rewarded in older versions.
            rewarded_result = await session.execute(
                select(User).where(
                    User.referred_by_telegram_id.is_not(None),
                    User.group_approved.is_(True),
                    User.referral_rewarded.is_(False),
                )
            )
            for user in rewarded_result.scalars().all():
                user.referral_rewarded = True

            # Legacy Kazhwan profiles that had a referrer but were never BTC-approved
            # did not receive the old BTC-tied reward. Award them once now.
            pending_reward_result = await session.execute(
                select(User).where(
                    User.referred_by_telegram_id.is_not(None),
                    User.referral_rewarded.is_(False),
                )
            )
            for user in pending_reward_result.scalars().all():
                ref_result = await session.execute(
                    select(User).where(User.telegram_id == user.referred_by_telegram_id)
                )
                referrer = ref_result.scalar_one_or_none()
                if referrer and referrer.telegram_id != user.telegram_id:
                    referrer.points += REFERRAL_REWARD_POINTS
                    referrer.referral_count += 1
                    user.referral_rewarded = True
                    session.add(
                        Activity(
                            telegram_id=referrer.telegram_id,
                            activity_type="referral",
                            title="معرفی عضو جدید کژوان",
                            details=(
                                f"{user.full_name} پروفایل کژوان را تکمیل کرد. "
                                f"+{REFERRAL_REWARD_POINTS} امتیاز (مهاجرت)"
                            ),
                        )
                    )

            # Existing BTC members keep their KZH code and receive a separate BTC code.
            btc_result = await session.execute(
                select(User).where(User.group_approved.is_(True)).order_by(User.id.asc())
            )
            for user in btc_result.scalars().all():
                existing_btc = await session.execute(
                    select(BtcMembership).where(BtcMembership.telegram_id == user.telegram_id)
                )
                if existing_btc.scalar_one_or_none() is None:
                    membership = BtcMembership(telegram_id=user.telegram_id, status="active", rules_accepted=True)
                    session.add(membership)
                    await session.flush()
                    membership.btc_code = f"BTC-{membership.id:06d}"

            await session.commit()

    @staticmethod
    def _migrate_users_table(sync_conn) -> None:
        """Small, idempotent migration that preserves the existing Railway data."""
        inspector = inspect(sync_conn)
        if "users" not in inspector.get_table_names():
            return

        existing = {column["name"] for column in inspector.get_columns("users")}
        dialect = sync_conn.dialect.name

        additions = {
            "referral_code": "VARCHAR(24)",
            "referred_by_telegram_id": "BIGINT",
            "referral_count": "INTEGER DEFAULT 0 NOT NULL",
            "referral_rewarded": "BOOLEAN DEFAULT FALSE NOT NULL",
            "group_approved": "BOOLEAN DEFAULT FALSE NOT NULL",
        }
        for name, sql_type in additions.items():
            if name not in existing:
                sync_conn.exec_driver_sql(f"ALTER TABLE users ADD COLUMN {name} {sql_type}")

        # Unique index keeps referral codes safe without rebuilding the existing table.
        sync_conn.exec_driver_sql(
            "CREATE UNIQUE INDEX IF NOT EXISTS ix_users_referral_code ON users (referral_code)"
        )
        sync_conn.exec_driver_sql(
            "CREATE INDEX IF NOT EXISTS ix_users_referred_by_telegram_id "
            "ON users (referred_by_telegram_id)"
        )


    @staticmethod
    def _migrate_group_moderation_table(sync_conn) -> None:
        """Persist quiet-hour settings so admins can change them without a deploy."""
        inspector = inspect(sync_conn)
        if "group_moderation_state" not in inspector.get_table_names():
            return
        existing = {c["name"] for c in inspector.get_columns("group_moderation_state")}
        if "quiet_enabled" not in existing:
            sync_conn.exec_driver_sql(
                "ALTER TABLE group_moderation_state ADD COLUMN quiet_enabled BOOLEAN DEFAULT TRUE NOT NULL"
            )
        if "quiet_start" not in existing:
            sync_conn.exec_driver_sql(
                "ALTER TABLE group_moderation_state ADD COLUMN quiet_start VARCHAR(5) DEFAULT '23:00' NOT NULL"
            )
        if "quiet_end" not in existing:
            sync_conn.exec_driver_sql(
                "ALTER TABLE group_moderation_state ADD COLUMN quiet_end VARCHAR(5) DEFAULT '11:00' NOT NULL"
            )

    @staticmethod
    def _migrate_trips_table(sync_conn) -> None:
        """Idempotent migration for trip categories and point awarding."""
        inspector = inspect(sync_conn)
        tables = inspector.get_table_names()
        if "trips" in tables:
            existing = {column["name"] for column in inspector.get_columns("trips")}
            # Manual trips can exist without a Telegram group. Railway uses PostgreSQL,
            # where dropping NOT NULL is safe and idempotent.
            if sync_conn.dialect.name == "postgresql":
                sync_conn.exec_driver_sql(
                    "ALTER TABLE trips ALTER COLUMN telegram_chat_id DROP NOT NULL"
                )
            if "trip_type" not in existing:
                sync_conn.exec_driver_sql(
                    "ALTER TABLE trips ADD COLUMN trip_type VARCHAR(24) DEFAULT 'domestic_multi' NOT NULL"
                )
            if "points_value" not in existing:
                sync_conn.exec_driver_sql(
                    "ALTER TABLE trips ADD COLUMN points_value INTEGER DEFAULT 15 NOT NULL"
                )
            # Convert the old two-category model to the new one. Existing domestic trips
            # are treated as multi-day until an admin redefines them with /settrip.
            sync_conn.exec_driver_sql(
                "UPDATE trips SET trip_type='domestic_multi' WHERE trip_type='domestic'"
            )
            sync_conn.exec_driver_sql(
                "UPDATE trips SET points_value=100 WHERE trip_type='international'"
            )
            sync_conn.exec_driver_sql(
                "UPDATE trips SET points_value=5 WHERE trip_type='domestic_day'"
            )
            sync_conn.exec_driver_sql(
                "UPDATE trips SET points_value=15 WHERE trip_type='domestic_multi'"
            )
            sync_conn.exec_driver_sql(
                "CREATE INDEX IF NOT EXISTS ix_trips_trip_type ON trips (trip_type)"
            )
            existing = {column["name"] for column in inspect(sync_conn).get_columns("trips")}
            if "archived" not in existing:
                sync_conn.exec_driver_sql(
                    "ALTER TABLE trips ADD COLUMN archived BOOLEAN DEFAULT FALSE NOT NULL"
                )
            if "archived_at" not in existing:
                sync_conn.exec_driver_sql(
                    "ALTER TABLE trips ADD COLUMN archived_at TIMESTAMP"
                )
            if "archived_chat_id" not in existing:
                sync_conn.exec_driver_sql(
                    "ALTER TABLE trips ADD COLUMN archived_chat_id BIGINT"
                )
            if "pre_archive_status" not in existing:
                sync_conn.exec_driver_sql(
                    "ALTER TABLE trips ADD COLUMN pre_archive_status VARCHAR(20)"
                )
            if "merged_into_trip_id" not in existing:
                sync_conn.exec_driver_sql(
                    "ALTER TABLE trips ADD COLUMN merged_into_trip_id INTEGER"
                )
            sync_conn.exec_driver_sql(
                "CREATE INDEX IF NOT EXISTS ix_trips_archived ON trips (archived)"
            )
            sync_conn.exec_driver_sql(
                "CREATE INDEX IF NOT EXISTS ix_trips_merged_into_trip_id ON trips (merged_into_trip_id)"
            )

        if "trip_participants" in tables:
            existing_participant = {
                column["name"] for column in inspector.get_columns("trip_participants")
            }
            if "points_awarded" not in existing_participant:
                sync_conn.exec_driver_sql(
                    "ALTER TABLE trip_participants ADD COLUMN points_awarded BOOLEAN DEFAULT FALSE NOT NULL"
                )
            if "awarded_points" not in existing_participant:
                sync_conn.exec_driver_sql(
                    "ALTER TABLE trip_participants ADD COLUMN awarded_points INTEGER DEFAULT 0 NOT NULL"
                )


    async def save_pending_join(
        self, telegram_id: int, group_chat_id: int, user_chat_id: int
    ) -> None:
        async with self.sessions() as session:
            pending = await session.get(PendingJoin, telegram_id)
            if pending:
                pending.group_chat_id = group_chat_id
                pending.user_chat_id = user_chat_id
                pending.created_at = datetime.now(timezone.utc)
            else:
                session.add(
                    PendingJoin(
                        telegram_id=telegram_id,
                        group_chat_id=group_chat_id,
                        user_chat_id=user_chat_id,
                    )
                )
            await session.commit()

    async def get_pending_join(self, telegram_id: int) -> PendingJoin | None:
        async with self.sessions() as session:
            return await session.get(PendingJoin, telegram_id)

    async def delete_pending_join(self, telegram_id: int) -> None:
        async with self.sessions() as session:
            pending = await session.get(PendingJoin, telegram_id)
            if pending:
                await session.delete(pending)
                await session.commit()

    async def get_user(self, telegram_id: int) -> User | None:
        async with self.sessions() as session:
            result = await session.execute(select(User).where(User.telegram_id == telegram_id))
            return result.scalar_one_or_none()

    async def get_user_by_referral_code(self, referral_code: str) -> User | None:
        code = referral_code.strip().upper().replace(" ", "")
        async with self.sessions() as session:
            result = await session.execute(
                select(User).where(func.upper(User.referral_code) == code)
            )
            return result.scalar_one_or_none()

    async def create_user(
        self,
        telegram_id: int,
        telegram_username: str | None,
        full_name: str,
        phone: str,
        city: str,
        discovery_source: str,
        referred_by_telegram_id: int | None = None,
    ) -> User:
        async with self.sessions() as session:
            user = User(
                telegram_id=telegram_id,
                telegram_username=telegram_username,
                full_name=full_name,
                phone=phone,
                city=city,
                discovery_source=discovery_source,
                referred_by_telegram_id=referred_by_telegram_id,
                rules_accepted=True,
                channel_verified=True,
                group_approved=False,
            )
            session.add(user)
            await session.flush()
            user.member_code = f"KZH-{user.id:06d}"
            user.referral_code = f"KZH-R{user.id:06d}"
            session.add(
                Activity(
                    telegram_id=telegram_id,
                    activity_type="membership",
                    title="ثبت پروفایل کژوان",
                    details=f"شناسه عضویت: {user.member_code}",
                )
            )
            await session.commit()
            await session.refresh(user)
            return user

    async def reward_referrer_if_needed(self, telegram_id: int) -> User | None:
        """Award the Kazhwan referral reward exactly once after profile completion."""
        async with self.sessions() as session:
            result = await session.execute(select(User).where(User.telegram_id == telegram_id))
            user = result.scalar_one_or_none()
            if not user or user.referral_rewarded or not user.referred_by_telegram_id:
                return user

            ref_result = await session.execute(
                select(User).where(User.telegram_id == user.referred_by_telegram_id)
            )
            referrer = ref_result.scalar_one_or_none()
            if referrer and referrer.telegram_id != user.telegram_id:
                referrer.points += REFERRAL_REWARD_POINTS
                referrer.referral_count += 1
                user.referral_rewarded = True
                session.add(
                    Activity(
                        telegram_id=referrer.telegram_id,
                        activity_type="referral",
                        title="معرفی عضو جدید کژوان",
                        details=(
                            f"{user.full_name} پروفایل کژوان را تکمیل کرد. "
                            f"+{REFERRAL_REWARD_POINTS} امتیاز"
                        ),
                    )
                )
                await session.commit()
                await session.refresh(user)
            return user

    async def ensure_btc_membership(self, telegram_id: int) -> BtcMembership | None:
        async with self.sessions() as session:
            user_result = await session.execute(
                select(User).where(User.telegram_id == telegram_id)
            )
            user = user_result.scalar_one_or_none()
            if not user:
                return None
            result = await session.execute(
                select(BtcMembership).where(BtcMembership.telegram_id == telegram_id)
            )
            membership = result.scalar_one_or_none()
            if membership:
                return membership
            membership = BtcMembership(telegram_id=telegram_id, status="active")
            session.add(membership)
            await session.flush()
            membership.btc_code = f"BTC-{membership.id:06d}"
            await session.commit()
            await session.refresh(membership)
            return membership

    async def get_btc_membership(self, telegram_id: int) -> BtcMembership | None:
        async with self.sessions() as session:
            result = await session.execute(
                select(BtcMembership).where(BtcMembership.telegram_id == telegram_id)
            )
            return result.scalar_one_or_none()

    async def mark_group_approved_and_reward_referrer(self, telegram_id: int) -> User | None:
        """Mark BTC approval and ensure a separate BTC membership code.

        The legacy method name is retained so deployed handlers remain compatible.
        Referral points are now Kazhwan-wide and awarded on profile completion.
        """
        async with self.sessions() as session:
            result = await session.execute(select(User).where(User.telegram_id == telegram_id))
            user = result.scalar_one_or_none()
            if not user:
                return None
            if not user.group_approved:
                user.group_approved = True
                session.add(
                    Activity(
                        telegram_id=user.telegram_id,
                        activity_type="btc_join",
                        title="عضویت Beyond The Clouds تأیید شد",
                        details=None,
                    )
                )
            btc_result = await session.execute(
                select(BtcMembership).where(BtcMembership.telegram_id == telegram_id)
            )
            membership = btc_result.scalar_one_or_none()
            if membership is None:
                membership = BtcMembership(
                    telegram_id=telegram_id, status="active", rules_accepted=True
                )
                session.add(membership)
                await session.flush()
                membership.btc_code = f"BTC-{membership.id:06d}"
            else:
                membership.rules_accepted = True
                membership.status = "active"
            await session.commit()
            await session.refresh(user)
            return user


    async def touch_member_activity(
        self, telegram_id: int, username: str | None, display_name: str
    ) -> None:
        now = datetime.now(timezone.utc)
        async with self.sessions() as session:
            activity = await session.get(MemberActivity, telegram_id)
            if activity:
                activity.telegram_username = username
                activity.display_name = display_name
                activity.last_activity_at = now
            else:
                session.add(
                    MemberActivity(
                        telegram_id=telegram_id,
                        telegram_username=username,
                        display_name=display_name,
                        first_seen_at=now,
                        last_activity_at=now,
                    )
                )

            result = await session.execute(
                select(User).where(User.telegram_id == telegram_id)
            )
            user = result.scalar_one_or_none()
            if user:
                user.last_activity_at = now
            await session.commit()

    async def ensure_member_activity(
        self, telegram_id: int, username: str | None, display_name: str
    ) -> None:
        async with self.sessions() as session:
            activity = await session.get(MemberActivity, telegram_id)
            if not activity:
                now = datetime.now(timezone.utc)
                session.add(
                    MemberActivity(
                        telegram_id=telegram_id,
                        telegram_username=username,
                        display_name=display_name,
                        first_seen_at=now,
                        last_activity_at=now,
                    )
                )
                await session.commit()

    async def list_inactive_members(self, days: int, limit: int = 100) -> list[MemberActivity]:
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        async with self.sessions() as session:
            result = await session.execute(
                select(MemberActivity)
                .where(MemberActivity.last_activity_at <= cutoff)
                .order_by(MemberActivity.last_activity_at.asc())
                .limit(limit)
            )
            return list(result.scalars().all())

    async def mark_existing_group_member(self, telegram_id: int) -> None:
        async with self.sessions() as session:
            result = await session.execute(
                select(User).where(User.telegram_id == telegram_id)
            )
            user = result.scalar_one_or_none()
            if not user:
                return
            user.group_approved = True
            btc_result = await session.execute(
                select(BtcMembership).where(BtcMembership.telegram_id == telegram_id)
            )
            membership = btc_result.scalar_one_or_none()
            if membership is None:
                membership = BtcMembership(
                    telegram_id=telegram_id, status="active", rules_accepted=True
                )
                session.add(membership)
                await session.flush()
                membership.btc_code = f"BTC-{membership.id:06d}"
            else:
                membership.rules_accepted = True
                membership.status = "active"
            await session.commit()

    async def get_quiet_settings(self, group_chat_id: int) -> dict:
        async with self.sessions() as session:
            state = await session.get(GroupModerationState, group_chat_id)
            if not state:
                state = GroupModerationState(
                    group_chat_id=group_chat_id, quiet_enabled=True, quiet_start="23:00", quiet_end="11:00"
                )
                session.add(state)
                await session.commit()
                await session.refresh(state)
            return {
                "enabled": bool(state.quiet_enabled),
                "start": state.quiet_start or "23:00",
                "end": state.quiet_end or "11:00",
            }

    async def update_quiet_settings(self, group_chat_id: int, *, enabled=None, start=None, end=None) -> dict:
        async with self.sessions() as session:
            state = await session.get(GroupModerationState, group_chat_id)
            if not state:
                state = GroupModerationState(group_chat_id=group_chat_id)
                session.add(state)
            if enabled is not None:
                state.quiet_enabled = bool(enabled)
            if start is not None:
                state.quiet_start = start
            if end is not None:
                state.quiet_end = end
            await session.commit()
            await session.refresh(state)
            return {"enabled": bool(state.quiet_enabled), "start": state.quiet_start, "end": state.quiet_end}

    async def count_btc_users(self) -> int:
        async with self.sessions() as session:
            result = await session.execute(
                select(func.count(BtcMembership.id)).where(BtcMembership.status == "active")
            )
            return int(result.scalar_one())

    async def get_saved_group_permissions(self, group_chat_id: int) -> str | None:
        async with self.sessions() as session:
            state = await session.get(GroupModerationState, group_chat_id)
            return state.saved_permissions_json if state else None

    async def save_group_permissions(self, group_chat_id: int, permissions_json: str) -> None:
        async with self.sessions() as session:
            state = await session.get(GroupModerationState, group_chat_id)
            if state:
                state.saved_permissions_json = permissions_json
            else:
                session.add(
                    GroupModerationState(
                        group_chat_id=group_chat_id,
                        saved_permissions_json=permissions_json,
                    )
                )
            await session.commit()

    async def clear_group_permissions(self, group_chat_id: int) -> None:
        async with self.sessions() as session:
            state = await session.get(GroupModerationState, group_chat_id)
            if state:
                state.saved_permissions_json = None
                await session.commit()

    async def list_users(self, limit: int = 5000) -> list[User]:
        async with self.sessions() as session:
            result = await session.execute(
                select(User).order_by(User.created_at.asc()).limit(limit)
            )
            return list(result.scalars().all())

    async def list_group_users(self, limit: int = 5000) -> list[User]:
        """Users whose membership in the main Kazhwan/BTC group was approved/confirmed."""
        async with self.sessions() as session:
            result = await session.execute(
                select(User)
                .where(User.group_approved.is_(True))
                .order_by(User.created_at.asc())
                .limit(limit)
            )
            return list(result.scalars().all())

    async def count_group_users(self) -> int:
        async with self.sessions() as session:
            result = await session.execute(
                select(func.count(User.id)).where(User.group_approved.is_(True))
            )
            return int(result.scalar_one())

    async def search_users(self, query: str, limit: int = 20) -> list[User]:
        value = query.strip()
        if not value:
            return []
        like = f"%{value}%"
        normalized = value.upper().replace(" ", "")
        async with self.sessions() as session:
            if normalized.startswith("BTC-"):
                btc_result = await session.execute(
                    select(User)
                    .join(BtcMembership, BtcMembership.telegram_id == User.telegram_id)
                    .where(func.upper(BtcMembership.btc_code).ilike(f"%{normalized}%"))
                    .order_by(User.full_name.asc())
                    .limit(limit)
                )
                btc_users = list(btc_result.scalars().all())
                if btc_users:
                    return btc_users
            conditions = [
                User.full_name.ilike(like),
                User.phone.ilike(like),
                User.telegram_username.ilike(like),
                func.upper(User.member_code).ilike(f"%{normalized}%"),
                func.upper(User.referral_code).ilike(f"%{normalized}%"),
            ]
            if value.lstrip("-").isdigit():
                conditions.append(User.telegram_id == int(value))
            result = await session.execute(
                select(User).where(or_(*conditions)).order_by(User.full_name.asc()).limit(limit)
            )
            return list(result.scalars().all())

    async def list_unregistered_seen_members(self, limit: int = 500) -> list[MemberActivity]:
        async with self.sessions() as session:
            result = await session.execute(
                select(MemberActivity)
                .outerjoin(User, User.telegram_id == MemberActivity.telegram_id)
                .where(User.id.is_(None))
                .order_by(MemberActivity.last_activity_at.desc())
                .limit(limit)
            )
            return list(result.scalars().all())

    async def list_top_referrers(self, limit: int = 20) -> list[User]:
        async with self.sessions() as session:
            result = await session.execute(
                select(User)
                .where(User.referral_count > 0)
                .order_by(User.referral_count.desc(), User.points.desc(), User.full_name.asc())
                .limit(limit)
            )
            return list(result.scalars().all())

    async def find_similar_trips(
        self, title: str, start_date_text: str, end_date_text: str, trip_type: str,
        exclude_trip_id: int | None = None, limit: int = 10,
    ) -> list[Trip]:
        """Find likely duplicate trips using normalized title + dates + type."""
        wanted_title = _normalize_name(title)
        wanted_start = _normalize_name(start_date_text)
        wanted_end = _normalize_name(end_date_text)
        async with self.sessions() as session:
            result = await session.execute(
                select(Trip).where(Trip.archived.is_(False)).order_by(Trip.created_at.desc())
            )
            trips = list(result.scalars().all())
        matches = []
        for trip in trips:
            if exclude_trip_id is not None and trip.id == exclude_trip_id:
                continue
            if (
                _normalize_name(trip.title) == wanted_title
                and _normalize_name(trip.start_date_text) == wanted_start
                and _normalize_name(trip.end_date_text) == wanted_end
                and trip.trip_type == trip_type
            ):
                matches.append(trip)
                if len(matches) >= limit:
                    break
        return matches

    async def create_or_update_trip(
        self,
        telegram_chat_id: int,
        title: str,
        start_date_text: str,
        end_date_text: str,
        trip_type: str,
        created_by_telegram_id: int,
    ) -> Trip:
        now = datetime.now(timezone.utc)
        points_value = TRIP_POINTS.get(trip_type, 0)
        async with self.sessions() as session:
            result = await session.execute(
                select(Trip).where(
                    Trip.telegram_chat_id == telegram_chat_id,
                    Trip.archived.is_(False),
                )
            )
            trip = result.scalar_one_or_none()
            if trip:
                trip.title = title
                trip.start_date_text = start_date_text
                trip.end_date_text = end_date_text
                trip.trip_type = trip_type
                trip.points_value = points_value
                trip.status = "open"
                trip.created_by_telegram_id = created_by_telegram_id
                trip.updated_at = now
            else:
                trip = Trip(
                    telegram_chat_id=telegram_chat_id,
                    title=title,
                    trip_type=trip_type,
                    points_value=points_value,
                    start_date_text=start_date_text,
                    end_date_text=end_date_text,
                    created_by_telegram_id=created_by_telegram_id,
                    status="open",
                    archived=False,
                    updated_at=now,
                )
                session.add(trip)
                await session.flush()
                trip.trip_code = f"TRIP-{trip.id:05d}"
            await session.commit()
            await session.refresh(trip)
            return trip

    async def create_manual_trip(
        self,
        title: str,
        start_date_text: str,
        end_date_text: str,
        trip_type: str,
        created_by_telegram_id: int,
    ) -> Trip:
        now = datetime.now(timezone.utc)
        async with self.sessions() as session:
            trip = Trip(
                telegram_chat_id=None,
                title=title.strip(),
                trip_type=trip_type,
                points_value=TRIP_POINTS.get(trip_type, 0),
                start_date_text=start_date_text.strip(),
                end_date_text=end_date_text.strip(),
                created_by_telegram_id=created_by_telegram_id,
                status="open",
                archived=False,
                updated_at=now,
            )
            session.add(trip)
            await session.flush()
            trip.trip_code = f"TRIP-{trip.id:05d}"
            await session.commit()
            await session.refresh(trip)
            return trip

    async def link_trip_to_chat(self, trip_id: int, telegram_chat_id: int) -> Trip | None:
        """Attach a Telegram group to an existing trip without creating a duplicate."""
        async with self.sessions() as session:
            trip = await session.get(Trip, trip_id)
            if not trip or trip.archived:
                return None
            result = await session.execute(
                select(Trip).where(
                    Trip.telegram_chat_id == telegram_chat_id,
                    Trip.id != trip_id,
                    Trip.archived.is_(False),
                )
            )
            old = result.scalar_one_or_none()
            if old:
                old.telegram_chat_id = None
                old.updated_at = datetime.now(timezone.utc)
            # A single trip currently has one primary Telegram group. If it was
            # linked elsewhere, the new group becomes the primary group.
            trip.telegram_chat_id = telegram_chat_id
            trip.updated_at = datetime.now(timezone.utc)
            await session.commit()
            await session.refresh(trip)
            return trip

    async def find_exact_user(self, full_name: str, phone: str | None = None) -> User | None:
        normalized_phone = _normalize_phone(phone)
        normalized_name = _normalize_name(full_name)
        async with self.sessions() as session:
            if normalized_phone:
                result = await session.execute(select(User))
                phone_matches = [u for u in result.scalars().all() if _normalize_phone(u.phone) == normalized_phone]
                if len(phone_matches) == 1:
                    return phone_matches[0]
            result = await session.execute(select(User))
            name_matches = [u for u in result.scalars().all() if _normalize_name(u.full_name) == normalized_name]
            return name_matches[0] if len(name_matches) == 1 else None

    async def create_or_get_guest(
        self, full_name: str, phone: str | None, created_by_telegram_id: int
    ) -> GuestTraveler:
        normalized_name = _normalize_name(full_name)
        normalized_phone = _normalize_phone(phone)
        async with self.sessions() as session:
            conditions = [
                GuestTraveler.linked_telegram_id.is_(None),
                GuestTraveler.normalized_name == normalized_name,
            ]
            if normalized_phone:
                conditions.append(GuestTraveler.normalized_phone == normalized_phone)
            result = await session.execute(select(GuestTraveler).where(*conditions).order_by(GuestTraveler.id.asc()))
            guest = result.scalars().first()
            if guest:
                if phone and not guest.phone:
                    guest.phone = phone
                    guest.normalized_phone = normalized_phone
                    await session.commit()
                return guest
            guest = GuestTraveler(
                full_name=full_name.strip(),
                normalized_name=normalized_name,
                phone=phone.strip() if phone else None,
                normalized_phone=normalized_phone,
                created_by_telegram_id=created_by_telegram_id,
            )
            session.add(guest)
            await session.commit()
            await session.refresh(guest)
            return guest

    async def get_guest(self, guest_id: int) -> GuestTraveler | None:
        async with self.sessions() as session:
            return await session.get(GuestTraveler, guest_id)

    async def register_guest_trip_participant(
        self, trip_id: int, guest_id: int, status: str = "attended"
    ) -> GuestTripParticipant:
        now = datetime.now(timezone.utc)
        async with self.sessions() as session:
            item = await session.get(GuestTripParticipant, (trip_id, guest_id))
            trip = await session.get(Trip, trip_id)
            pending = int(trip.points_value or 0) if trip and status == "attended" else 0
            if item:
                item.status = status
                item.pending_points = pending
                item.updated_at = now
            else:
                item = GuestTripParticipant(
                    trip_id=trip_id, guest_id=guest_id, status=status,
                    pending_points=pending, updated_at=now
                )
                session.add(item)
            await session.commit()
            await session.refresh(item)
            return item

    async def set_guest_trip_participant_status(
        self, trip_id: int, guest_id: int, status: str
    ) -> GuestTripParticipant | None:
        async with self.sessions() as session:
            item = await session.get(GuestTripParticipant, (trip_id, guest_id))
            if not item:
                return None
            trip = await session.get(Trip, trip_id)
            item.status = status
            item.pending_points = int(trip.points_value or 0) if trip and status == "attended" else 0
            item.updated_at = datetime.now(timezone.utc)
            await session.commit()
            await session.refresh(item)
            return item

    async def list_guest_trip_participants(
        self, trip_id: int
    ) -> list[tuple[GuestTripParticipant, GuestTraveler]]:
        async with self.sessions() as session:
            result = await session.execute(
                select(GuestTripParticipant, GuestTraveler)
                .join(GuestTraveler, GuestTraveler.id == GuestTripParticipant.guest_id)
                .where(GuestTripParticipant.trip_id == trip_id)
                .order_by(GuestTripParticipant.declared_at.asc())
            )
            return list(result.all())

    async def list_unlinked_guests(self, limit: int = 200) -> list[GuestTraveler]:
        async with self.sessions() as session:
            result = await session.execute(
                select(GuestTraveler)
                .where(GuestTraveler.linked_telegram_id.is_(None))
                .order_by(GuestTraveler.created_at.desc())
                .limit(limit)
            )
            return list(result.scalars().all())

    async def find_guest_match_candidates(
        self, full_name: str, phone: str | None = None, limit: int = 10
    ) -> list[GuestTraveler]:
        normalized_name = _normalize_name(full_name)
        normalized_phone = _normalize_phone(phone)
        async with self.sessions() as session:
            result = await session.execute(
                select(GuestTraveler)
                .where(GuestTraveler.linked_telegram_id.is_(None))
                .order_by(GuestTraveler.created_at.asc())
            )
            guests = list(result.scalars().all())
        matches = []
        for guest in guests:
            phone_match = bool(normalized_phone and guest.normalized_phone == normalized_phone)
            name_match = guest.normalized_name == normalized_name
            if phone_match or name_match:
                matches.append(guest)
            if len(matches) >= limit:
                break
        return matches

    async def link_guest_to_user(self, guest_id: int, telegram_id: int) -> dict | None:
        async with self.sessions() as session:
            guest = await session.get(GuestTraveler, guest_id)
            user_result = await session.execute(select(User).where(User.telegram_id == telegram_id))
            user = user_result.scalar_one_or_none()
            if not guest or not user or guest.linked_telegram_id is not None:
                return None
            rows = await session.execute(
                select(GuestTripParticipant, Trip)
                .join(Trip, Trip.id == GuestTripParticipant.trip_id)
                .where(GuestTripParticipant.guest_id == guest_id)
                .order_by(GuestTripParticipant.declared_at.asc())
            )
            points_added = 0
            linked_trips = []
            for guest_participant, trip in rows.all():
                participant = await session.get(TripParticipant, (trip.id, telegram_id))
                if participant is None:
                    participant = TripParticipant(
                        trip_id=trip.id, telegram_id=telegram_id, status=guest_participant.status,
                        declared_at=guest_participant.declared_at, updated_at=datetime.now(timezone.utc),
                        points_awarded=False, awarded_points=0,
                    )
                    session.add(participant)
                    await session.flush()
                elif participant.status != "attended" and guest_participant.status == "attended":
                    participant.status = "attended"
                    participant.updated_at = datetime.now(timezone.utc)

                if participant.status == "attended" and not participant.points_awarded:
                    points = int(trip.points_value or TRIP_POINTS.get(trip.trip_type, 0))
                    user.points += points
                    participant.points_awarded = True
                    participant.awarded_points = points
                    points_added += points
                    session.add(Activity(
                        telegram_id=telegram_id, activity_type="trip_attended",
                        title=f"شرکت در سفر {trip.title}",
                        details=f"{trip.trip_code} | +{points} امتیاز | اتصال سابقه دستی",
                    ))
                linked_trips.append(trip.title)
                await session.delete(guest_participant)

            guest.linked_telegram_id = telegram_id
            guest.linked_at = datetime.now(timezone.utc)
            await session.commit()
            return {
                "guest_name": guest.full_name,
                "user_name": user.full_name,
                "trip_titles": linked_trips,
                "points_added": points_added,
                "total_points": user.points,
            }

    async def get_trip_by_chat_id(self, telegram_chat_id: int) -> Trip | None:
        async with self.sessions() as session:
            result = await session.execute(
                select(Trip).where(
                    Trip.telegram_chat_id == telegram_chat_id,
                    Trip.archived.is_(False),
                )
            )
            return result.scalar_one_or_none()

    async def get_trip(self, trip_id: int) -> Trip | None:
        async with self.sessions() as session:
            return await session.get(Trip, trip_id)

    async def list_trips(self, limit: int = 100) -> list[Trip]:
        async with self.sessions() as session:
            result = await session.execute(
                select(Trip)
                .where(Trip.archived.is_(False))
                .order_by(Trip.created_at.desc())
                .limit(limit)
            )
            return list(result.scalars().all())

    async def list_archived_trips(self, limit: int = 100) -> list[Trip]:
        async with self.sessions() as session:
            result = await session.execute(
                select(Trip)
                .where(Trip.archived.is_(True))
                .order_by(Trip.archived_at.desc(), Trip.created_at.desc())
                .limit(limit)
            )
            return list(result.scalars().all())

    async def set_trip_status(self, trip_id: int, status: str) -> Trip | None:
        async with self.sessions() as session:
            trip = await session.get(Trip, trip_id)
            if not trip:
                return None
            trip.status = status
            trip.updated_at = datetime.now(timezone.utc)
            await session.commit()
            await session.refresh(trip)
            return trip

    async def archive_trip(self, trip_id: int) -> Trip | None:
        """Soft-delete a trip and reverse points awarded only by this trip."""
        async with self.sessions() as session:
            trip = await session.get(Trip, trip_id)
            if not trip or trip.archived:
                return trip
            now = datetime.now(timezone.utc)
            rows = await session.execute(
                select(TripParticipant).where(TripParticipant.trip_id == trip_id)
            )
            for participant in rows.scalars().all():
                if participant.points_awarded and participant.awarded_points:
                    user_result = await session.execute(
                        select(User).where(User.telegram_id == participant.telegram_id)
                    )
                    user = user_result.scalar_one_or_none()
                    if user:
                        user.points = max(0, user.points - int(participant.awarded_points or 0))
                    participant.points_awarded = False
                    participant.awarded_points = 0
            guest_rows = await session.execute(
                select(GuestTripParticipant).where(GuestTripParticipant.trip_id == trip_id)
            )
            for participant in guest_rows.scalars().all():
                participant.pending_points = 0
            trip.pre_archive_status = trip.status if trip.status != "archived" else (trip.pre_archive_status or "closed")
            trip.status = "archived"
            trip.archived = True
            trip.archived_at = now
            trip.archived_chat_id = trip.telegram_chat_id
            trip.telegram_chat_id = None
            trip.updated_at = now
            await session.commit()
            await session.refresh(trip)
            return trip

    async def restore_trip(self, trip_id: int) -> Trip | None:
        """Restore an archived non-merged trip and reapply attended points once."""
        async with self.sessions() as session:
            trip = await session.get(Trip, trip_id)
            if not trip or not trip.archived or trip.merged_into_trip_id is not None:
                return None
            trip.archived = False
            trip.archived_at = None
            trip.status = trip.pre_archive_status or "closed"
            trip.pre_archive_status = None
            if trip.archived_chat_id is not None:
                conflict = await session.execute(
                    select(Trip).where(
                        Trip.telegram_chat_id == trip.archived_chat_id,
                        Trip.id != trip.id,
                        Trip.archived.is_(False),
                    )
                )
                if conflict.scalar_one_or_none() is None:
                    trip.telegram_chat_id = trip.archived_chat_id
            trip.archived_chat_id = None
            trip.updated_at = datetime.now(timezone.utc)
            rows = await session.execute(
                select(TripParticipant).where(TripParticipant.trip_id == trip_id)
            )
            for participant in rows.scalars().all():
                if participant.status == "attended" and not participant.points_awarded:
                    user_result = await session.execute(
                        select(User).where(User.telegram_id == participant.telegram_id)
                    )
                    user = user_result.scalar_one_or_none()
                    if user:
                        points = int(trip.points_value or TRIP_POINTS.get(trip.trip_type, 0))
                        user.points += points
                        participant.points_awarded = True
                        participant.awarded_points = points
            guest_rows = await session.execute(
                select(GuestTripParticipant).where(GuestTripParticipant.trip_id == trip_id)
            )
            for participant in guest_rows.scalars().all():
                participant.pending_points = int(trip.points_value or 0) if participant.status == "attended" else 0
            await session.commit()
            await session.refresh(trip)
            return trip

    async def merge_trips(self, source_trip_id: int, target_trip_id: int) -> dict | None:
        """Merge a duplicate source trip into target, preserving people and de-duplicating points."""
        if source_trip_id == target_trip_id:
            return None
        priority = {"cancelled": 0, "declared": 1, "attended": 2}
        async with self.sessions() as session:
            source = await session.get(Trip, source_trip_id)
            target = await session.get(Trip, target_trip_id)
            if not source or not target or source.archived or target.archived:
                return None
            source_chat = source.telegram_chat_id
            target_chat = target.telegram_chat_id

            real_rows = await session.execute(
                select(TripParticipant).where(TripParticipant.trip_id == source_trip_id)
            )
            moved_real = 0
            adjusted_points = 0
            for sp in list(real_rows.scalars().all()):
                tp = await session.get(TripParticipant, (target_trip_id, sp.telegram_id))
                old_awarded = int(sp.awarded_points or 0) if sp.points_awarded else 0
                if tp is not None and tp.points_awarded:
                    old_awarded += int(tp.awarded_points or 0)
                merged_status = sp.status
                if tp is not None and priority.get(tp.status, 0) >= priority.get(sp.status, 0):
                    merged_status = tp.status
                if tp is None:
                    tp = TripParticipant(
                        trip_id=target_trip_id, telegram_id=sp.telegram_id, status=merged_status,
                        declared_at=sp.declared_at, updated_at=datetime.now(timezone.utc),
                        points_awarded=False, awarded_points=0,
                    )
                    session.add(tp)
                    await session.flush()
                else:
                    tp.status = merged_status
                    tp.updated_at = datetime.now(timezone.utc)
                    if sp.declared_at and (not tp.declared_at or sp.declared_at < tp.declared_at):
                        tp.declared_at = sp.declared_at
                desired = int(target.points_value or 0) if merged_status == "attended" else 0
                user_result = await session.execute(select(User).where(User.telegram_id == sp.telegram_id))
                user = user_result.scalar_one_or_none()
                delta = desired - old_awarded
                if user and delta:
                    user.points = max(0, user.points + delta)
                    adjusted_points += delta
                tp.points_awarded = desired > 0
                tp.awarded_points = desired
                await session.delete(sp)
                moved_real += 1

            guest_rows = await session.execute(
                select(GuestTripParticipant).where(GuestTripParticipant.trip_id == source_trip_id)
            )
            moved_guests = 0
            for sp in list(guest_rows.scalars().all()):
                tp = await session.get(GuestTripParticipant, (target_trip_id, sp.guest_id))
                merged_status = sp.status
                if tp is not None and priority.get(tp.status, 0) >= priority.get(sp.status, 0):
                    merged_status = tp.status
                if tp is None:
                    tp = GuestTripParticipant(
                        trip_id=target_trip_id, guest_id=sp.guest_id, status=merged_status,
                        pending_points=int(target.points_value or 0) if merged_status == "attended" else 0,
                        declared_at=sp.declared_at, updated_at=datetime.now(timezone.utc),
                    )
                    session.add(tp)
                else:
                    tp.status = merged_status
                    tp.pending_points = int(target.points_value or 0) if merged_status == "attended" else 0
                    tp.updated_at = datetime.now(timezone.utc)
                    if sp.declared_at and (not tp.declared_at or sp.declared_at < tp.declared_at):
                        tp.declared_at = sp.declared_at
                await session.delete(sp)
                moved_guests += 1

            # Prefer an existing target group; otherwise inherit the source group.
            if target.telegram_chat_id is None and source_chat is not None:
                target.telegram_chat_id = source_chat
            source.archived_chat_id = source_chat
            source.telegram_chat_id = None
            source.pre_archive_status = source.status
            source.status = "archived"
            source.archived = True
            source.archived_at = datetime.now(timezone.utc)
            source.merged_into_trip_id = target_trip_id
            source.updated_at = datetime.now(timezone.utc)
            target.updated_at = datetime.now(timezone.utc)
            await session.commit()
            return {
                "source_title": source.title, "target_title": target.title,
                "moved_real": moved_real, "moved_guests": moved_guests,
                "points_delta": adjusted_points,
                "source_group_detached": bool(source_chat and target_chat and source_chat != target_chat),
            }

    async def register_trip_participant(self, trip_id: int, telegram_id: int) -> TripParticipant:
        now = datetime.now(timezone.utc)
        async with self.sessions() as session:
            participant = await session.get(TripParticipant, (trip_id, telegram_id))
            if participant:
                participant.status = "declared"
                participant.updated_at = now
            else:
                participant = TripParticipant(
                    trip_id=trip_id, telegram_id=telegram_id, status="declared", updated_at=now
                )
                session.add(participant)
            user_result = await session.execute(
                select(User).where(User.telegram_id == telegram_id)
            )
            user = user_result.scalar_one_or_none()
            trip = await session.get(Trip, trip_id)
            if user and trip:
                existing_activity = await session.execute(
                    select(Activity).where(
                        Activity.telegram_id == telegram_id,
                        Activity.activity_type == "trip_declared",
                        Activity.details == trip.trip_code,
                    )
                )
                if existing_activity.scalar_one_or_none() is None:
                    session.add(
                        Activity(
                            telegram_id=telegram_id,
                            activity_type="trip_declared",
                            title=f"اعلام حضور در سفر {trip.title}",
                            details=trip.trip_code,
                        )
                    )
            await session.commit()
            return participant

    async def set_trip_participant_status(
        self, trip_id: int, telegram_id: int, status: str
    ) -> TripParticipant | None:
        async with self.sessions() as session:
            participant = await session.get(TripParticipant, (trip_id, telegram_id))
            if not participant:
                return None

            trip = await session.get(Trip, trip_id)
            user_result = await session.execute(
                select(User).where(User.telegram_id == telegram_id)
            )
            user = user_result.scalar_one_or_none()

            # Reversible and idempotent points: only attended earns points.
            if status == "attended":
                if trip and user and not participant.points_awarded:
                    points = int(trip.points_value or TRIP_POINTS.get(trip.trip_type, 0))
                    user.points += points
                    participant.points_awarded = True
                    participant.awarded_points = points
                    session.add(
                        Activity(
                            telegram_id=telegram_id,
                            activity_type="trip_attended",
                            title=f"شرکت در سفر {trip.title}",
                            details=f"{trip.trip_code} | +{points} امتیاز",
                        )
                    )
            elif participant.points_awarded:
                # If an admin corrects an attended status, remove the previously-awarded trip points.
                if user:
                    user.points = max(0, user.points - int(participant.awarded_points or 0))
                participant.points_awarded = False
                participant.awarded_points = 0

            participant.status = status
            participant.updated_at = datetime.now(timezone.utc)
            await session.commit()
            await session.refresh(participant)
            return participant


    async def list_trip_participants(self, trip_id: int) -> list[tuple[TripParticipant, User | None]]:
        async with self.sessions() as session:
            result = await session.execute(
                select(TripParticipant, User)
                .outerjoin(User, User.telegram_id == TripParticipant.telegram_id)
                .where(TripParticipant.trip_id == trip_id)
                .order_by(TripParticipant.declared_at.asc())
            )
            return list(result.all())

    async def count_trip_participants(self, trip_id: int) -> int:
        async with self.sessions() as session:
            result = await session.execute(
                select(func.count()).select_from(TripParticipant).where(TripParticipant.trip_id == trip_id)
            )
            return int(result.scalar_one())

    async def list_user_trips(self, telegram_id: int) -> list[tuple[TripParticipant, Trip]]:
        async with self.sessions() as session:
            result = await session.execute(
                select(TripParticipant, Trip)
                .join(Trip, Trip.id == TripParticipant.trip_id)
                .where(
                    TripParticipant.telegram_id == telegram_id,
                    Trip.archived.is_(False),
                )
                .order_by(Trip.created_at.desc())
            )
            return list(result.all())


    async def list_all_trip_history(self) -> list[tuple[TripParticipant, Trip]]:
        async with self.sessions() as session:
            result = await session.execute(
                select(TripParticipant, Trip)
                .join(Trip, Trip.id == TripParticipant.trip_id)
                .where(Trip.archived.is_(False))
                .order_by(TripParticipant.telegram_id.asc(), Trip.created_at.asc())
            )
            return list(result.all())

    async def list_activities(self, telegram_id: int, limit: int = 15) -> list[Activity]:
        async with self.sessions() as session:
            result = await session.execute(
                select(Activity)
                .where(Activity.telegram_id == telegram_id)
                .order_by(Activity.created_at.desc())
                .limit(limit)
            )
            return list(result.scalars().all())

    async def count_users(self) -> int:
        async with self.sessions() as session:
            result = await session.execute(select(func.count(User.id)))
            return int(result.scalar_one())
